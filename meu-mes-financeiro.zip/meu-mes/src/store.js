import {createClient} from '@supabase/supabase-js';
const url=import.meta.env.VITE_SUPABASE_URL,key=import.meta.env.VITE_SUPABASE_ANON_KEY;
export const db=url&&key?createClient(url,key):null;
export const localKey='meu-mes-demo-v1';
export function loadLocal(){try{return JSON.parse(localStorage.getItem(localKey))}catch{return null}}
export async function readCloud(user){const {data,error}=await db.from('finance_states').select('*').eq('user_id',user.id).maybeSingle();if(error)throw error;return data;}
export async function writeCloud(user,state,revision){
 if(revision===null){const {data,error}=await db.from('finance_states').insert({user_id:user.id,data:state}).select().single();if(error)throw error;return data.revision;}
 const {data,error}=await db.from('finance_states').update({data:state,revision:revision+1,updated_at:new Date().toISOString()}).eq('user_id',user.id).eq('revision',revision).select();if(error)throw error;if(!data.length)throw Error('Dados alterados em outro dispositivo. Recarregue a página antes de continuar.');return data[0].revision;
}
