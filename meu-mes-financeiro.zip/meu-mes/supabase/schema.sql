-- Execute no SQL Editor do seu projeto Supabase.
create table if not exists public.finance_states (
 user_id uuid primary key references auth.users(id) on delete cascade,
 data jsonb not null default '{}'::jsonb,
 revision bigint not null default 1,
 updated_at timestamptz not null default now()
);
alter table public.finance_states enable row level security;
revoke all on public.finance_states from anon;
grant select,insert,update on public.finance_states to authenticated;
create policy "Ler meus dados" on public.finance_states for select to authenticated using ((select auth.uid()) = user_id);
create policy "Criar meus dados" on public.finance_states for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "Atualizar meus dados" on public.finance_states for update to authenticated using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);
-- O cliente atualiza somente a revisão que leu. Em conflito, recarrega antes de salvar.
