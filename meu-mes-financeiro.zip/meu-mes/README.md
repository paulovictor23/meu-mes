# Meu mês

Controle financeiro pessoal responsivo em React + Vite. Visual claro/escuro, envelopes, despesas, receitas extras, aportes, contas previstas, histórico, edição, filtros, CSV e backup JSON. Código pronto para GitHub + Cloudflare Pages. Não há assinatura obrigatória do projeto. Os planos gratuitos dos provedores têm limites próprios.

## 1. Experimente antes de configurar

Abra `DEMO.html` em um navegador de computador. É uma versão compilada independente, sem login e sem conexão com Supabase. Os dados permanecem neste navegador. Ela não contém pagamentos históricos nem dados bancários. O armazenamento pode variar quando o navegador abre arquivos locais; para uso real, publique o site. Alternativa: publique o conteúdo da pasta `dist` no Cloudflare Pages por upload direto para experimentar. Se pretende conectar GitHub, crie o projeto Pages com integração Git desde o início.

## 2. Crie o banco gratuito

1. Crie um projeto no Supabase. Guarde a senha administrativa em local seguro.
2. No SQL Editor, cole e execute `supabase/schema.sql` uma vez. Isso cria a tabela e as políticas que separam os dados por usuário.
3. Em Authentication → Users → Add user, crie sua conta pessoal com e-mail e senha. Se disponível, marque a confirmação de e-mail para esse usuário criado por você. Não existe cadastro público na interface deste site.
4. Em Authentication → Providers/Sign In, desative novos cadastros se somente você usará o projeto. Não desative o login por e-mail/senha.
5. Nas configurações de API do projeto, copie a URL e a chave pública `anon` ou `publishable`.
6. NUNCA use `service_role`, chave secreta ou senha do banco nas variáveis VITE_. Variáveis VITE_ fazem parte do JavaScript público. A segurança depende do login e das políticas RLS do SQL.

## 3. Coloque o código no GitHub

1. Crie um repositório, por exemplo `meu-mes`, de preferência privado.
2. Extraia este ZIP. Envie o CONTEÚDO da pasta `meu-mes` para a raiz do repositório. `package.json` deve ficar na raiz, e não em outra subpasta.
3. Inclua `src`, `public`, `supabase`, `index.html`, `package.json`, `package-lock.json`, `.gitignore`, `.env.example` e este README.
4. Não envie `node_modules`, `.env`, `.env.local`, backups pessoais ou a planilha com seus dados. `dist` e `DEMO.html` são opcionais e não são necessários no repositório.

O repositório contém valores de orçamento e nomes de contas derivados da sua planilha. Mantenha-o privado ou substitua os valores em `src/finance.js` antes de torná-lo público. A interface do site será acessível pela URL; no modo Supabase, os registros financeiros só são carregados após o login.

## 4. Publique no Cloudflare Pages pelo GitHub

1. No Cloudflare, abra Workers & Pages e escolha criar um projeto **Pages** conectado ao Git. Os nomes dos botões podem variar. Não escolha um Worker com comando de deploy Wrangler.
2. Autorize o GitHub para acessar apenas o repositório desejado e selecione `meu-mes`.
3. Branch de produção: `main` (ou a branch que você utiliza).
4. Preset: Vite. Comando de build: `npm run build`. Diretório de saída: `dist`. Diretório raiz: deixe vazio se `package.json` está na raiz.
5. Antes do primeiro build, adicione as variáveis de ambiente de produção:

   - `VITE_SUPABASE_URL`: URL do seu projeto.
   - `VITE_SUPABASE_ANON_KEY`: chave pública anon/publishable.
   - `NODE_VERSION`: `22`.

6. Publique. Ao terminar, abra a URL `https://seu-projeto.pages.dev` e entre com a conta criada no Supabase.
7. Se você adicionou variáveis depois de publicar, faça um novo deploy/build. Elas são incorporadas durante a compilação.
8. Em Authentication → URL Configuration no Supabase, configure a URL do seu site como Site URL. O login atual usa senha e não precisa de redirecionamento por link.
9. Faça um lançamento de teste, recarregue e entre em outro dispositivo para conferir a sincronização.

Você não precisa ativar GitHub Pages nem configurar um comando de deploy. Novos commits na branch de produção geram novos builds do Cloudflare Pages.

## 5. Uso no iPhone

Abra a URL no Safari → Compartilhar → Adicionar à Tela de Início. O layout se adapta ao celular. A página exige internet para login e gravações na nuvem; não há fila offline nesta versão. O manifesto permite abrir como experiência independente quando suportado pelo navegador. Não há Service Worker nem cache offline.

## 6. Ajuste seu primeiro mês

- Não importamos lançamentos históricos: as abas da planilha não tinham mês identificado.
- Receita inicial planejada: R$ 4.280,00.
- Fixos: R$ 2.910,02. Lazer: R$ 296,00, conforme subtotal da planilha (o cabeçalho dizia R$ 400,00).
- Reserva para extras: R$ 214,88. Emergências: R$ 40,00. Guardar: R$ 820,00.
- A alocação inicial total é R$ 4.280,90. Ajuste os R$ 0,90 excedentes no Planejamento.
- Guardar contém as metas Liberdade Financeira (R$ 420) e Longo prazo (R$ 400).
- Em Planejamento você edita a receita, os limites, nomes e valores das contas previstas e valores das duas metas. Também pode criar/remover contas previstas.
- Ao tocar em Registrar numa conta, o lançamento fica vinculado a ela. Mercado/gasolina podem ter vários registros no mesmo mês. Uma despesa em Fixos sem vínculo consome o envelope, mas não abate uma conta prevista específica.
- Em Ajustes, “Usar mês como padrão” define o modelo dos meses ainda não personalizados. Meses sem planejamento salvo seguem esse modelo. Para preservar valores específicos de um mês, salve seu planejamento nele.
- Receitas extras somam à receita planejada: não registre novamente o salário já contemplado no planejamento.
- Exportação CSV inclui os registros filtrados por mês, sem os filtros de pesquisa/envelope. Backup JSON inclui todos os meses e configurações.
- Não há dados de cartão sensíveis nem credenciais bancárias armazenados.

## 7. Regras de cálculo

Todos os valores são inteiros em centavos. Campo de valor aceita `48,90` ou `48.90`, sem separador de milhares.

- Orçamento de consumo = Fixos + Lazer + Reserva para extras + Emergências.
- Previsto restante = soma de máximo(0, previsto da conta − despesas vinculadas à conta no mês).
- Disponível = orçamento de consumo − despesas do mês − previsto restante.
- Aportes em Guardar não são despesas de consumo.
- Saldo do planejamento = receita planejada + receitas extras − despesas − aportes. Não é saldo bancário real: não há saldo inicial de conta, conciliação bancária ou atualização de extrato.
- Limites dos envelopes não mudam automaticamente quando você altera a receita.
- Compras em cartão contam na data informada. Não lance o pagamento da fatura novamente. Para uma compra parcelada, registre manualmente cada parcela na data correspondente. Não há fechamento de cartão automático.
- Emergências aqui é um envelope de orçamento mensal, não um saldo acumulado de fundo de emergência.

## 8. Dados e sincronização

Sem as duas variáveis Supabase, o site opera em modo local e mostra uma faixa informativa. Com elas, exige login. Dados locais NÃO são enviados automaticamente à nuvem. Para transferir: exporte o JSON no modo local e restaure-o depois de configurar e entrar na conta.

A gravação na nuvem acontece após cada alteração confirmada. Erros mantêm o formulário aberto. Há controle de revisão para evitar sobrescrever dados alterados em outro dispositivo. Ao trocar de dispositivo, recarregue o site para buscar o estado atual. Em conflito, exporte o que precisar e recarregue antes de refazer a alteração; não há atualização em tempo real.

O banco guarda um documento JSON por usuário com políticas RLS. Essa escolha simplifica a primeira versão pessoal. Para muitos registros, análises SQL ou automação, migre para tabelas normalizadas de lançamentos e configurações. Projetos Supabase Free podem pausar por baixa atividade. Faça backups JSON periódicos; o ZIP do código não é backup dos seus lançamentos.

Se você esquecer a senha, pode redefini-la administrativamente no Supabase; a interface ainda não tem fluxo de recuperação de senha. Não há autenticação biométrica própria ou captura bancária.

## 9. Desenvolvimento local

Instale Node.js 22 LTS. No terminal na pasta do projeto:

```bash
npm ci
npm run dev
```

Para nuvem em desenvolvimento, copie `.env.example` para `.env.local` e preencha com sua URL e chave pública. Reinicie o servidor depois de alterar essas variáveis.

```bash
npm test
npm run build
```

Testes cobrem conversão monetária e previsão parcial sem duplicar aportes/consumo. A compilação valida o pacote de produção. Integração com Supabase precisa ser verificada no seu projeto após executar o SQL e configurar as variáveis. Não houve publicação nas suas contas GitHub/Cloudflare nem validação visual automatizada em navegador neste ambiente.
